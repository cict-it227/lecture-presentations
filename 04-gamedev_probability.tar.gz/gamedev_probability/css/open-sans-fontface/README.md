# Open Sans @font-face kit

I split the SASS file, so the developer can decide which fonts and styles she or he really needs.

Installable via [Bower](http://twitter.github.com/bower/):
```
bower install open-sans-fontface
```

## Demo
__Our repository:__ [http://fontfacekit.github.com/open-sans](http://fontfacekit.github.com/open-sans)

__Google Web Fonts:__ [http://www.google.com/fonts/specimen/Open+Sans](http://www.google.com/fonts/specimen/Open+Sans)


## Maintain your own font-face in FontFaceKit
Contact @gustavohenke if you want to maintain your own font-face in this repository.
